<ul>
<?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
	<a href="<?php echo e(route('livros.show', ['id'=>$livro->id_livro])); ?>">
	
	<h4><?php echo e($livro->titulo); ?></h4></a></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<a href="<?php echo e(route('livros.create', ['id'=>$livro->id_livro])); ?>"><h4>Criar</h4></a>
<?php /**PATH F:\Atividade-6\livraria\resources\views/livros/index.blade.php ENDPATH**/ ?>