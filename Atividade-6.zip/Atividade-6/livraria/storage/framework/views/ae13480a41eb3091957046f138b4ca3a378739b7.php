<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('livros.store')); ?>" method="post">
<?php echo csrf_field(); ?>
Titulo: <input type="text" name="titulo"><br><br>
Idioma: <input type="text" name="idioma"><br><br>
Total Páginas: <input type="text" name="total_paginas"><br><br>
Data Edição: <input type="date" name="data_edicao"><br><br>
ISBN: <input type="text" name="isbn"><br><br>
Observacoes: <textarea type="text" name="observacoes" ></textarea><br><br>
Imagem de capa: <input type="text" name="imagem_capa"><br><br>
Género: <input type="text" name="id_genero"><br><br>
Autor: <input type="text" name="id_autor"><br><br>
Sinopse: <textarea type="text" name="sinopse"></textarea> <br><br>
<input type="submit" value="Enviar!">
</form>

<?php if($errors->has('isbn')): ?>
<i>Deverá indicar um ISBN correto (13 carateres)</i>
<?php endif; ?>

<?php if($errors->has('titulo')): ?>
<i>Deverá indicar um Titulo correto</i>
<?php endif; ?>

<?php if($errors->has('idioma')): ?>
<i>Deverá indicar um Idioma correto </i>
<?php endif; ?>

<?php if($errors->has('total_paginas')): ?>
<i>Deverá indicar o total páginas correto </i>
<?php endif; ?>

<?php if($errors->has('data_edicao')): ?>
<i>Deverá indicar uma Data de Edição correto </i>
<?php endif; ?>

<?php if($errors->has('isbn')): ?>
<i>Deverá indicar um isbn correto </i>
<?php endif; ?>

<?php if($errors->has('observacoes')): ?>
<i>Deverá indicar as Observações corretas </i>
<?php endif; ?>

<?php if($errors->has('imagem_capa')): ?>
<i>Deverá indicar uma Imagem de capa correta </i>
<?php endif; ?>

<?php if($errors->has('genero')): ?>
<i>Deverá indicar um Género correto </i>
<?php endif; ?>

<?php if($errors->has('autor')): ?>
<i>Deverá indicar um Autor correto </i>
<?php endif; ?>

<?php if($errors->has('sinopse')): ?>
<i>Deverá indicar uma Sinopse correta </i>
<?php endif; ?>
</body>
</html>

<?php /**PATH D:\PSI\Atividade-6\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>