<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('generos.store')); ?>" method="post">
<?php echo csrf_field(); ?>
Designação: <input type="text" name="designacao"><br><br>
Observações: <input type="text" name="observacoes"><br><br>
<input type="submit" value="Enviar!">
</form>


<?php if($errors->has('designacao')): ?>
<i>Deverá indicar uma Designação correta</i>
<?php endif; ?>

<?php if($errors->has('observacoes')): ?>
<i>Deverá indicar uma observação correta </i>
<?php endif; ?>

</body>
</html>

<?php /**PATH D:\PSI\Atividade-6\livraria\resources\views/generos/create.blade.php ENDPATH**/ ?>