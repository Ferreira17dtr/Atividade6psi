<ul>
<?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
	<a href="<?php echo e(route('livros.show', ['id'=>$livro->id_livro])); ?>">
	
	<?php echo e($livro->titulo); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<?php /**PATH C:\Users\Admin\Desktop\PSI-Atividade-5-main\Atividade-5\livraria\resources\views/livros/index.blade.php ENDPATH**/ ?>